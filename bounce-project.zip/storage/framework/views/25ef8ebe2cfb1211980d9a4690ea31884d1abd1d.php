

<?php $__env->startSection('content'); ?>

<section class="content">
  <div class="container-fluid">
    <h1>SELAMAT DATANG</h1>
  </div>

  <script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/Chart.min.js')); ?>"></script>
  
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/home/V_home.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/select2.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/select2-bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Edit Roles</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('user-access/'.$data['id'])); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label for="roles">Nama User*</label>
            <input type="text" class="form-control" id="roles" aria-describedby="rolesHelp" placeholder="Enter Admin" name="roles" value="<?php echo e($data['name']); ?>" disabled required>
          </div>
          <div class="form-group">
            <label>Roles</label>
            <select class="form-control select2 select2-danger" data-dropdown-css-class="select2-danger" name="roles" style="width: 100%;">
              <option selected> Select Role </option>
              <?php $__currentLoopData = $data['roles_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($role->name); ?>" <?php if (in_array($role->name, $data['roles'])) echo 'selected' ?>><?php echo e($role->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->get('roles')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('roles'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorroles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorroles); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label>Permissions</label>
            <div class="select2-purple">
              <select class="select2" multiple="multiple" data-placeholder="Select a Permission" data-dropdown-css-class="select2-purple" name="permissions[]" style="width: 100%;">
                <?php $__currentLoopData = $data['permissions_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($permission->name); ?>" <?php if (in_array($permission->name, $data['permissions'])) echo 'selected' ?>><?php echo e($permission->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if($errors->get('permissions')): ?>
              <div class="invalid-feedback" style="display: block;">
                <ul style="list-style: none;">
                  <?php $__currentLoopData = $errors->get('permissions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($errorpermissions); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">
            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            Submit
          </button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

</section>

<!-- Select2 -->
<script src="<?php echo e(url('/adminlte/plugins/js/select2.full.min.js')); ?>"></script>

<script>
  $('#form').submit(() => {
    $('.spinner-border').removeClass('d-none').addClass('d-inline-block')
  })

  $('.select2').select2({
    closeOnSelect: false
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/access/V_edit_manage_useraccess.blade.php ENDPATH**/ ?>
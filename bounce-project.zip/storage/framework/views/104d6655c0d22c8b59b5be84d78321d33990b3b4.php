

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Add Permisions</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('permissions')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="permissions">Nama Permissions*</label>
            <input type="text" class="form-control" id="permissions" aria-describedby="permissionsHelp" placeholder="Enter Permission" name="permissions" value="<?php echo e(old('permissions')); ?>" required>
            <?php if($errors->get('permissions')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('permissions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorpermissions); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary">
            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            Submit
          </button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

</section>

<script>
  $('#form').submit(() => {
    $('.spinner-border').removeClass('d-none').addClass('d-inline-block')
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/access/V_add_manage_permissions.blade.php ENDPATH**/ ?>
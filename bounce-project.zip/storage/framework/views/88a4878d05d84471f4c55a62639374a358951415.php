

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <div class="row">
        <h3 class="card-title">Manage User</h3>
      </div>
      <div class="row mt-3">
        <div class="col-12 text-right">
          <a href="<?php echo e(url('/export-parking')); ?>" class="btn btn-success">Export</a>
        </div>
      </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr class="text-center">
            <th>ID</th>
            <th>User</th>
            <th>Nopol</th>
            <th>Kode</th>
            <th>IN</th>
            <th>OUT</th>
            <th>Status</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="text-center">
            <td><?php echo e($data->id); ?></td>
            <td><?php echo e($data->user->name); ?></td>
            <td><?php echo e($data->nopol); ?></td>
            <td><?php echo e($data->code); ?></td>
            <td><?php echo e($data->intime); ?></td>
            <td><?php echo e($data->outtime); ?></td>
            <td><?php echo e($data->status); ?></td>
            <td><?php echo e($data->created_at); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>

  <input id="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

  <!-- DataTables -->
  <script src="<?php echo e(url('/adminlte/plugins/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/responsive.bootstrap4.min.js')); ?>"></script>

  <!-- AdminLTE App -->

  <script>
    $(function() {
      $(" #example1").DataTable({
        "responsive": true,
        "autoWidth": false,
        "order": [
          [0, "desc"]
        ]
      });
    });
  </script>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/manage_parking/V_parking.blade.php ENDPATH**/ ?>
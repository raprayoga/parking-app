

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Edit Profile</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('edit-password-process')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="password_lama">Password Lama</label>
            <input type="password" class="form-control" id="password_lama" aria-describedby="emailHelp" placeholder="Enter Password" name="password_lama" required>
            <?php if($errors->get('password_lama')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('password_lama'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpassword_lama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorpassword_lama); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="password">Password Baru</label>
            <input type="password" class="form-control" id="password" placeholder="Enter Password Baru" name="password" minlength="8" required>
            <small style="color: red;">Password minimal 8 karakter dengan kombinasi huruf, angka, dan simbol</small>
            <?php if($errors->get('password')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpassword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorpassword); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="password_confirmation">Konfirmasi Password Baru</label>
            <input type="password" class="form-control" id="password_confirmation" placeholder="Enter Konfirmasi Password Baru" name="password_confirmation" minlength="8" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

    <?php if(session()->has('updateerror')): ?>
    <script>
      Swal.fire({
        icon: 'error',
        title: 'Oops... failed to process',
        text: '<?= session('updateerror') ?>'
      })
    </script>
    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/home/V_edit_password.blade.php ENDPATH**/ ?>
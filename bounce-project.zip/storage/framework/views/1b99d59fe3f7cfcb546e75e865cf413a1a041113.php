

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/daterangepicker.css')); ?>">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/tempusdominus-bootstrap-4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Add User</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('manage-user')); ?>" id="form" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="name">Name*</label>
            <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter name" name="name" value="<?php echo e(old('name')); ?>" required>
            <?php if($errors->get('name')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorname); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="email">Email*</label>
            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter Email" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if($errors->get('email')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erroremail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($erroremail); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="password">Password*</label>
            <input type="password" class="form-control" id="password" aria-describedby="passwordHelp" placeholder="Enter password" name="password" value="<?php echo e(old('password')); ?>" required>
            <?php if($errors->get('password')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpassword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorpassword); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary">
            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            Submit
          </button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

</section>

<!-- InputMask -->
<script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('/adminlte/plugins/js/jquery.inputmask.bundle.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(url('/adminlte/plugins/js/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(url('/adminlte/plugins/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<script>
  //Date range picker
  $('#tgl_lahir').datetimepicker({
    format: 'Y-M-D'
  });
</script>

<script>
  $('#form').submit(() => {
    $('.spinner-border').removeClass('d-none').addClass('d-inline-block')
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/manage_user/V_add_user.blade.php ENDPATH**/ ?>
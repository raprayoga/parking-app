

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">List Roles</h3>
      <div class="row">
        <div class="col-12 text-right">
          <a href="<?php echo e(url('/roles/create')); ?>" class="btn btn-info"><i class="fas fa-plus-circle"></i> Add Roles</a>
        </div>
      </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr class="text-center">
            <th>ID</th>
            <th>Nama</th>
            <th>Guard Name</th>
            <th>Permissions</th>
            <th>Created At</th>
            <th>Updated At</th>
            <td>Actions</td>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="text-center">
            <td><?php echo e($data->id); ?></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->guard_name); ?></td>
            <td>
              <?php $__currentLoopData = $data->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="btn btn-outline-info btn-sm"><?php echo e($permission->name); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($data->created_at); ?></td>
            <td><?php echo e($data->updated_at); ?></td>
            <td class="text-center">
              <form action="<?php echo e(url('/roles/'.$data->id)); ?>" onsubmit="return confirm('Do you really want to delete it?');" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(url('/roles/'.$data->id.'/edit')); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-edit" style="color: white;"></i></a>
                <button type="submit" class="btn btn-sm btn-danger" title="Delete"><i class="fas fa-trash-alt" style="color: white;"></i></button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>

  <!-- DataTables -->
  <script src="<?php echo e(url('/adminlte/plugins/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/responsive.bootstrap4.min.js')); ?>"></script>

  <!-- AdminLTE App -->

  <script>
    $(function() {
      $(" #example1").DataTable({
        "responsive": true,
        "autoWidth": false,
      });
    });
  </script>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/access/V_manage_roles.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Edit Profile</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('edit-profile-process')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email" value="<?php echo e($data->email); ?>" required>
            <?php if($errors->get('email')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorEmail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorEmail); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo e($data->name); ?>" required>
            <?php if($errors->get('name')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorname); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

    <script>
      function prvwimg() {
        const gambarProfile = document.querySelector("#gambar-profile");
        const label = document.querySelector(".custom-file-label");
        const imgprvw = document.querySelector(".img-profile");

        label.textContent = gambarProfile.files[0].name;

        const filegambar = new FileReader();
        filegambar.readAsDataURL(gambarProfile.files[0]);

        filegambar.onload = function(e) {
          imgprvw.src = e.target.result;
        };
      }
    </script>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/home/V_edit_profile.blade.php ENDPATH**/ ?>
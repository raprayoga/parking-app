

<?php $__env->startSection('content'); ?>

<section class="content">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/responsive.bootstrap4.min.css')); ?>">

  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/select2.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/adminlte/plugins/css/select2-bootstrap4.min.css')); ?>">

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Add Roles</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <div class="container">
        <form action="<?php echo e(url('roles')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="roles">Nama Roles*</label>
            <input type="text" class="form-control" id="roles" aria-describedby="rolesHelp" placeholder="Enter Role" name="roles" value="<?php echo e(old('roles')); ?>" required>
            <?php if($errors->get('roles')): ?>
            <div class="invalid-feedback" style="display: block;">
              <ul style="list-style: none;">
                <?php $__currentLoopData = $errors->get('roles'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorroles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errorroles); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label>Permissions</label>
            <div class="select2-purple">
              <select class="select2" multiple="multiple" data-placeholder="Select a State" data-dropdown-css-class="select2-purple" name="permissions[]" style="width: 100%;">
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->name); ?>"><?php echo e($data->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if($errors->get('permissions')): ?>
              <div class="invalid-feedback" style="display: block;">
                <ul style="list-style: none;">
                  <?php $__currentLoopData = $errors->get('permissions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorpermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($errorpermissions); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">
            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            Submit
          </button>
        </form>
      </div>
      <!-- /.card-body -->
    </div>

</section>

<!-- Select2 -->
<script src="<?php echo e(url('/adminlte/plugins/js/select2.full.min.js')); ?>"></script>

<script>
  $('#form').submit(() => {
    $('.spinner-border').removeClass('d-none').addClass('d-inline-block')
  })

  $('.select2').select2()
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/access/V_add_manage_roles.blade.php ENDPATH**/ ?>
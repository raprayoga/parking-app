

<?php $__env->startSection('content'); ?>

<section class="content">
  <div class="container d-flex justify-content-center">
    <div class="login-box">
      <!-- /.login-logo -->
      <div class="card">
        <div class="card-body login-card-body">
          <p class="login-box-msg">Masukkan Nomor Polisi</p>

          <form action="<?php echo e(url('parking-gatein')); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
              <input type="text" class="form-control  <?php echo e($errors->has('nopol') ? 'error' : ''); ?>" placeholder="Nomor Polisi" name="nopol">
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-scroll"></span>
                </div>
              </div>
              <?php if($errors->get('nopol')): ?>
              <div class="invalid-feedback" style="display: block;">
                <ul style="list-style: none;">
                  <?php $__currentLoopData = $errors->get('nopol'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorNopol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($errorNopol); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
            </div>
            <div class="row">
              <div class="col-4 offset-8">
                <button type="submit" class="btn btn-primary btn-block">
                  <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                  Submit
                </button>
              </div>
              <!-- /.col -->
            </div>
          </form>
        </div>
        <!-- /.login-card-body -->
      </div>
    </div>
  </div>

  <script src="<?php echo e(url('/adminlte/plugins/js/moment.min.js')); ?>"></script>
  <script src="<?php echo e(url('/adminlte/plugins/js/Chart.min.js')); ?>"></script>

</section>

<script>
  $('#form').submit(() => {
    $('.spinner-border').removeClass('d-none').addClass('d-inline-block')
  })
</script>

<?php if(session()->has('submitsuccess')): ?>
<script>
  Swal.fire({
    icon: 'success',
    title: 'successfully processed',
    text: '<?= session('submitsuccess') ?>'
  })
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/template/V_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bounce-project\resources\views/parking/V_gatein.blade.php ENDPATH**/ ?>
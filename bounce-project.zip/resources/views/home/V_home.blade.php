@extends('/template/V_template')

@section('content')

<section class="content">
  <div class="container-fluid">
    <h1>SELAMAT DATANG</h1>
  </div>

  <script src="{{ url('/adminlte/plugins/js/moment.min.js') }}"></script>
  <script src="{{ url('/adminlte/plugins/js/Chart.min.js') }}"></script>
  
</section>

@endsection